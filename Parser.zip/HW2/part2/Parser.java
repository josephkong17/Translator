/* *** This file is given as part of the programming assignment. *** */
    
//this program takes in .e files and checks if the tokens in it represent a valid program


public class Parser {


    // tok is global to all these parsing methods;
    // scan just calls the scanner's scan method and saves the result in tok.
    private Token tok; // the current token
    private void scan() {
	tok = scanner.scan();
    }

    private Scan scanner;
    Parser(Scan scanner) {
	this.scanner = scanner;
	scan();
	program();
	if( tok.kind != TK.EOF )
	    parse_error("junk after logical end of program");
    }

    //calls block according to the grammar
    private void program() {
	block();
    }

    //calls declaration list first, then calls statement list according to the grammar
    private void block(){
	declaration_list();
	statement_list();
    }

    //if it finds an @ symbol, calls declaration, otherwise returns void
    private void declaration_list() {
	// below checks whether tok is in first set of declaration.
	// here, that's easy since there's only one token kind in the set.
	// in other places, though, there might be more.
	// so, you might want to write a general function to handle that.
	while( is(TK.DECLARE) ) {
	    declaration();
	}
    }
    
    //must have a declaration of a variable, checks for multiple variables declared on same line
    private void declaration() {
    	mustbe(TK.DECLARE);
    	mustbe(TK.ID);
        	while( is(TK.COMMA) ) {
        	    scan();
        	    mustbe(TK.ID);
        	}
    }

    //while it finds a ~, ID, !, <, or [ calls statement otherwise returns void
    private void statement_list() {
        while( is(TK.TILDE) || is(TK.ID) || is(TK.PRINT) || is(TK.DO) || is(TK.IF) ) {
            statement();
        }
    }
    
    //statement calls different functions according to the grammar based on what token it finds
    private void statement() {
        if ( is(TK.TILDE)) {
            //scan();
            assignment();
        }
        else if ( is(TK.PRINT)) {
            //scan();
            print();
        }
        else if ( is(TK.DO)) {
            //scan();
            _do();
        }
        else if ( is(TK.IF)) {
            //scan();
            _if();
        }
        else if ( is(TK.ID)) {
            assignment();
        }
    }
    
    //must find the ! token, calls expression
    private void print() {
        mustbe(TK.PRINT);
        expr();
    }
    
    //checks that it's a variable according to the grammar, then looks for an = and then calls expr
    private void assignment() {
        ref_id();
        mustbe(TK.ASSIGN);
        expr();
    }
    
    //checks if there's a ~, then if there's a number following it, else must be ID according to the grammar
    private void ref_id() {
        if (is(TK.TILDE)) {
            scan();
            if (is(TK.NUM)) {
                scan();
                mustbe(TK.ID);
            }
            else{
                //scan();
                mustbe(TK.ID);
            }
        }
        
        else {
            mustbe(TK.ID);
        }
    }
    
    //must find <, calls guarded_command according to grammar
    private void _do() {
        mustbe(TK.DO);
        guarded_command();
        mustbe(TK.ENDDO);
    }
    
    //must find [ token, also checks for | tokens and % tokens, then calls functions according to the grammar
    private void _if() {
        mustbe(TK.IF);
        guarded_command();
        while ( is(TK.ELSEIF)) { //use of scan or not?
            scan(); //hereee, proven
            guarded_command();
        }
        if ( is(TK.ELSE)) {
            scan(); //proven
            block();
        }
        mustbe(TK.ENDIF);
    }
    
    //finds an expr, checks for : symbol, then calls a new block
    private void guarded_command() {
        expr();
        mustbe(TK.THEN);
        block();
    }
    
    //calls term, deals with + and -
    private void expr() {
        term();
        while ( is(TK.PLUS) || is(TK.MINUS)) {
            scan(); //hereee
            term();
        }
    }
    
    //calls factor, deals with * and /
    private void term() {
        factor();
        while ( is(TK.TIMES) || is(TK.DIVIDE)) {
            scan(); //hereeee
            factor();
        }
    }
    
    //deals with paranthesis or terminal variables or numbers
    private void factor() {
        if ( is(TK.LPAREN)) {
            scan();
            expr();
            mustbe(TK.RPAREN);
        }
        else if ( is(TK.TILDE) || is(TK.ID)) {
            //scan();
            ref_id();
        }
        else {
            mustbe(TK.NUM);
        }
    }
    
    //terminal + or -
    private void addop() {
        if ( is(TK.PLUS)) {
            scan();
            mustbe(TK.PLUS);
        }
        else {
            mustbe(TK.MINUS);
        }
    }
    
    //terminal * or /
    private void multop() {
        if ( is(TK.TIMES)) {
            scan();
            mustbe(TK.TIMES);
        }
        else {
            mustbe(TK.DIVIDE);
        }
    }

    // is current token what we want?
    private boolean is(TK tk) {
        return tk == tok.kind;
    }

    // ensure current token is tk and skip over it.
    private void mustbe(TK tk) {
	if( tok.kind != tk ) {
	    System.err.println( "mustbe: want " + tk + ", got " +
				    tok);
	    parse_error( "missing token (mustbe)" );
	}
	scan();
    }

    private void parse_error(String msg) {
	System.err.println( "can't parse: line "
			    + tok.lineNumber + " " + msg );
	System.exit(1);
    }
}